export const apiBaseUrl =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://10.0.24.81:8081";
